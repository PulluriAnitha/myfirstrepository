<?php
define( 'WP_CACHE', true );




/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'asntuzyy_wp499' );

/** Database username */
define( 'DB_USER', 'asntuzyy_wp499' );

/** Database password */
define( 'DB_PASSWORD', 'v))2](Fwpp728)S4' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'mhse8cs6g0gzwmqcohs0eyzgvbzjesv7vprjwerjsipqwqzi6iyr1rf0hnxw1qbf' );
define( 'SECURE_AUTH_KEY',  'fakhkjnmtal7ghb3uzlraqdt9wpzf9mnxqgz5jcl5jqhsucml2y0z1koncse8a4e' );
define( 'LOGGED_IN_KEY',    'o7nisnekrne9fbw01fwopdp4rykqtulxnfhyqwosbyfsel1j2juiomlswniriuxi' );
define( 'NONCE_KEY',        'vutvbqqppnhpiqums92as4ekpjjenk3v6rem3smthqhvy8qwhmkforcy0phkic9d' );
define( 'AUTH_SALT',        'rq8atjcfh9bzvqvprbbeqfvrjxxzwneizuvpisf8oclfiirfk2lnnlpgyn2301tk' );
define( 'SECURE_AUTH_SALT', 'uwkohprus7bktb69ehzrflqhirc95rhmpz1m7zmxxjiyhrjysfs7qnqzhvxemk3x' );
define( 'LOGGED_IN_SALT',   'b3w00rvb7dfvawcmds0erinqs7nxi1uyzwkn7uvfnggxozy8jro9aqcwytbm012r' );
define( 'NONCE_SALT',       'yyrkezebtjqw0doqok8oc6rhptdnpldixcuc4slffg5x0kojyrs96somlli8mzua' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp1s_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
